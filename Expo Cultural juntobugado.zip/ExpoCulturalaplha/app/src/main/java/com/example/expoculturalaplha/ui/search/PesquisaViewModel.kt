package com.example.expoculturalaplha.ui.search

import androidx.lifecycle.ViewModel

class PesquisaViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}