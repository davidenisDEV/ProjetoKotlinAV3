package com.example.expoculturalaplha.ui.obras

import androidx.lifecycle.ViewModel

class ObrasViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}